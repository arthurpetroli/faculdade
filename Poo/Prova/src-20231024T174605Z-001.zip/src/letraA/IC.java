/*
Autor:Sefora Davanso de Assis
Ra: 23677777
*/
package letraA;

public interface IC {
    public abstract void b1();
    public abstract void b2();  
    public abstract void b3();
}


