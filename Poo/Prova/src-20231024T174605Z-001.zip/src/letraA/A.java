/*
Autor:  Sefora Davanso de Assis
RA: 2367777
*/
package letraA;


public abstract class A extends B {
    public abstract void a1();
    public abstract void a2();  
}
