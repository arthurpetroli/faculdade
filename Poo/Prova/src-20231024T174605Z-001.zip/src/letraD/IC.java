/*
Autor:  Sefora Davanso de Assis
RA: 2367777
*/
package letraD;

public interface IC {

    public abstract int b1();
    public abstract int b2( );  
    public abstract int b3();    
}


